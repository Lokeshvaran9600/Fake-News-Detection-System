
  # Fix Image Upload Issues

  This is a code bundle for Fix Image Upload Issues. The original project is available at https://www.figma.com/design/dvcpxHqHackegxVXpTdBGp/Fix-Image-Upload-Issues.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  